from brain_games.play_game import brain_games


def main():
    brain_games()


if __name__ == "__main__":
    main()
